# Class: User
#
# Description:
#    Class for storing user data

class User
  
  attr_accessor :accounts

  def initialize
    @accounts = []
  end
end
